<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ReservationController extends Controller
{
    function getData(Request $req)
    {
     $req->validate([
         'name'=> 'required | max:25' ,
         'lastname'=> 'required |max:25',
         'email'=> 'required | max:30',
         'date'=> 'required',
         'tel'=> 'required |max: 11'
     ]);
        return $req->input();
    }
}
