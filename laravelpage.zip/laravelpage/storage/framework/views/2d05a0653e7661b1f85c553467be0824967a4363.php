<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-icon" href="<?php echo e(URL('storage/icon.png')); ?>">
    <title>Cartoon city</title>
    <link rel="stylesheet" href="<?php echo e(asset('landcss/style.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
</head>

<body>
    <style>

    </style>
    <header>
        <img src="<?php echo e(URL('storage/icon.png')); ?>" class="logo" alt="">
    </header>
    <?php echo $__env->yieldContent('landing'); ?>
    <h1 class="landing">Cartoon landing</h1>
    <img src="<?php echo e(URL('storage/top.png')); ?>" class="cartoon" alt="">
    <img src="<?php echo e(Url('storage/SpryPointedDungbeetle.webp')); ?>" class="snow" alt="">
    <?php $__env->startSection('landing'); ?>
        <div class="sec">
        </div>
        <img src="<?php echo e(URL('storage/tj.png')); ?>" class="tom" alt="">

        <div class="slideshow-container fade">


            <div class="Containers">
                <div class="MessageInfo">1 / 6</div>
                <img src="<?php echo e(URL('storage/p1.png')); ?>" style="width:35%">
                <div class="Info">Up Animation</div>
            </div>

            <div class="Containers">
                <div class="MessageInfo">2 / 6</div>
                <img src="<?php echo e(URL('storage/p2.png')); ?>" style="width:35%">
                <div class="Info">Iron Man</div>
            </div>

            <div class="Containers">
                <div class="MessageInfo">3 / 6</div>
                <img src="<?php echo e(URL('storage/spiderman.png')); ?>" style="width:35%">
                <div class="Info">Spider Man</div>
            </div>
            <div class="Containers">
                <div class="MessageInfo">4 / 6</div>
                <img src="<?php echo e(URL('storage/p4.png')); ?>" style="width:35%">
                <div class="Info">Avengers</div>
            </div>
            <div class="Containers">
                <div class="MessageInfo">5 / 6</div>
                <img src="<?php echo e(URL('storage/p5.png')); ?>" style="width:35%; ">
                <div class="Info">Capitan America</div>
            </div>
            <div class="Containers">
                <div class="MessageInfo">6 / 6</div>
                <img src="<?php echo e(URL('storage/ninja.png')); ?>" style="width:35%">
                <div class="Info">Ninja Turtle </div>
            </div>


            <a class="Back" onclick="plusSlides(-1)">&#10094;</a>
            <a class="forward" onclick="plusSlides(1)">&#10095;</a>
        </div>
        <div class="about">

            <img src="<?php echo e(url('storage/pixar-software.jpg')); ?>" class="about-img" alt="">

            <div class="text">
                <p class="about-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi sed impedit
                    similique distinctio alias eveniet, vero voluptatibus dolor dicta recusandae cupiditate ducimus
                    architecto aliquam eum saepe. Odio eaque consectetur aperiam inventore aliquid cupiditate eius excepturi
                    accusamus exercitationem beatae nisi nostrum recusandae dolorem nemo delectus ab, aut in cumque facilis
                    sed magni. Ipsa minima incidunt nemo molestiae! Autem, commodi officia, similique itaque ut aliquid
                    dolorum alias dicta quas sequi sit nisi. Omnis eligendi, dignissimos repellat ullam deleniti voluptas
                    est porro enim! Illum distinctio voluptatem pariatur ea provident cupiditate fugiat, quaerat aliquid
                    nisi laudantium numquam labore vitae quibusdam sapiente possimus ipsum similique aut eligendi magnam
                    nostrum fuga officia? Expedita necessitatibus, ratione laboriosam veritatis quia similique delectus
                    consequatur eligendi quas nesciunt magni non magnam, officia eaque ipsam facere odio, nulla explicabo
                    maiores fugiat dolorem ut atque consectetur corporis! Impedit reprehenderit sint eos cum, labore
                    doloremque hic enim inventore distinctio quos ipsa suscipit sunt alias in nisi commodi delectus facere
                    aut amet? Possimus maxime quod delectus modi corrupti? Autem adipisci laborum provident aperiam placeat
                    quo, dicta quibusdam fugiat deserunt quasi iure, id enim, quae voluptate laudantium beatae fuga
                    repudiandae a maxime animi velit. Vitae ea numquam illo neque maxime ducimus quam fuga necessitatibus.
                    Modi doloremque nisi voluptatibus enim illum quam hic ad, iusto optio quibusdam ipsa deserunt, nobis
                    dolor eveniet aliquid, soluta fuga! Dolorem, magnam beatae sequi quasi corporis voluptatibus hic
                    exercitationem in omnis assumenda officiis repellendus voluptates iusto tempore porro accusamus suscipit
                    laborum blanditiis quas! Expedita suscipit voluptatum hic id quibusdam magnam quis.</p>
            </div>
            <div class="circle">
                <h1 class="abouth1">About us </h1>
            </div>
        </div>
        <h2 class="reservation">Reservation Form</h2>

        <form action="reserv" method="POST">
            <?php echo csrf_field(); ?>
            <input type="text" name="name" class="form" placeholder="Your Name"><br>
            <span class="error"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>


                <br>
                <input type="text" name="lastname" class="form" placeholder="Your LastName"><br>
                <span class="error"><?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?>


                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                <br>
                <input type="email" name="email" class="form" placeholder="Your Email"><br>
                <span class="error"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>


                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                <br>
                <input type="datetime-local" name="date" id="" class="form"><br>
                <span class="error"><?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>



                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                <br>
                <input type="tel" name="tel" id="" class="form" placeholder="phoneNumber"><br>
                <span class="error">
                    <?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  
                </span>
                <br>
                <button class="submit" type="submit">Send</button>
            </form>

            <?php $__env->startSection('map'); ?>
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6996659.27365784!2d-95.58466802628186!3d31.10034933421212!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x864070360b823249%3A0x16eb1c8f1808de3c!2z2Krar9iy2KfYs9iMINin24zYp9mE2KfYqiDZhdiq2K3Yr9mHINii2YXYsduM2qnYpw!5e0!3m2!1sfa!2snl!4v1639640806803!5m2!1sfa!2snl"
                    width="450" height="450" style="border:0;" allowfullscreen="" loading="lazy" class="map"></iframe>



                <div style="text-align:center; font-family:title; font-size: 35px; color:deeppink" class="our">
                    <h2>Our Enviroment</h2>
                    <p>Check Our Services</p>
                </div>


                <div class="row">
                    <div class="column" onclick="openTab('b1');">
                        <img src="<?php echo e(url('storage/0_psm_SCU_160715kidsfun_11.jpg')); ?>" class="fimg" alt="">
                    </div>
                    <div class="column" onclick="openTab('b2');">
                        <img src="<?php echo e(url('storage/park.webp')); ?>" class="fimg" alt="">
                    </div>
                    <div class="column" onclick="openTab('b3');">
                        <img src="<?php echo e(url('storage/grid-gamenet.2f4c01ed.jpg')); ?>" class="fimg" alt="">
                    </div>
                    <div class="column" onclick="openTab('b4');">
                        <img src="<?php echo e(url('storage/we-pudding-barcelone.jpg')); ?>" class="fimg" alt="">
                    </div>
                    <div class="column" onclick="openTab('b5');">
                        <img src="<?php echo e(url('storage/cartoon-boy-painting-on-white-background-vector-28464822.jpg')); ?>"
                            class="fimg" alt="">
                    </div>
                    <div class="column" onclick="openTab('b6');">
                        <img src="<?php echo e(url('storage/sweet land.jpg')); ?>" class="fimg" alt="">
                    </div>
                </div>


                <div id="b1" class="containerTab" style="display:none;background:rgb(115, 241, 255)">
                    <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
                    <h2>3d Cinema</h2>
                    <p>Lorem ipsum dolor sit amet, te quo doctus abhorreant, et pri deleniti intellegat, te sanctus inermis
                        ullamcorper nam. Ius error diceret deseruisse ad</p>
                </div>

                <div id="b2" class="containerTab" style="display:none;background:rgb(115, 241, 255)">
                    <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
                    <h2>Amusment Park</h2>
                    <p>Lorem ipsum dolor sit amet, te quo doctus abhorreant, et pri deleniti intellegat, te sanctus inermis
                        ullamcorper nam. Ius error diceret deseruisse ad</p>
                </div>

                <div id="b3" class="containerTab" style="display:none;background:rgb(115, 241, 255)">
                    <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
                    <h2>Play Room</h2>
                    <p>Lorem ipsum dolor sit amet, te quo doctus abhorreant, et pri deleniti intellegat, te sanctus inermis
                        ullamcorper nam. Ius error diceret deseruisse ad</p>
                </div>
                <div id="b4" class="containerTab" style="display:none;background:rgb(115, 241, 255)">
                    <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
                    <h2>Cartoon Resturant</h2>
                    <p>Lorem ipsum dolor sit amet, te quo doctus abhorreant, et pri deleniti intellegat, te sanctus inermis
                        ullamcorper nam. Ius error diceret deseruisse ad</p>
                </div>
                <div id="b5" class="containerTab" style="display:none;background:rgb(115, 241, 255)">
                    <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
                    <h2>Painting Room</h2>
                    <p>Lorem ipsum dolor sit amet, te quo doctus abhorreant, et pri deleniti intellegat, te sanctus inermis
                        ullamcorper nam. Ius error diceret deseruisse ad</p>
                </div>
                <div id="b6" class="containerTab" style="display:none;background:rgb(115, 241, 255)">
                    <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
                    <h2>Sweet Land</h2>
                    <p>Lorem ipsum dolor sit amet, te quo doctus abhorreant, et pri deleniti intellegat, te sanctus inermis
                        ullamcorper nam. Ius error diceret deseruisse ad</p>
                </div>
                
                <Footer>
                    <div>
                        <div>

                            <h3 class="pfoot">Stay With Us </h3>

                            <img src="<?php echo e(url('storage/Daco_780907.png')); ?>" class="imgfoot" alt="">
                        </div>
                    </div>
                    <p class="privilage"> All privilage Reserved by: &hearts; </p>
                </Footer>













                <script src="<?php echo e(asset('landjs/land.js')); ?>"></script>
            </body>

            </html>
<?php /**PATH C:\laragon\www\Desktop\landingPage\resources\views/landing.blade.php ENDPATH**/ ?>